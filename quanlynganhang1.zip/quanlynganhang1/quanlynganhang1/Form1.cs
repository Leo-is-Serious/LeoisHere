﻿using quanlynganhang1.userControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace quanlynganhang1
{
    public partial class Form1 : Form
    {
       
       
        

        public Form1()
        {
            InitializeComponent();
        }
         private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel2.Controls.Clear();
            panel2.Controls.Add(userControl);
         userControl.BringToFront();
           
        }
        private void clientButton1_Click(object sender, EventArgs e)
        {
            ClientControl clientControl = new ClientControl();
            addUserControl(clientControl);
        }

        private void BankButton_Click(object sender, EventArgs e)
        {
            BankControl bankControl = new BankControl();
            addUserControl((BankControl)bankControl);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveControl saveControl = new SaveControl();
            addUserControl(saveControl);
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchControl searchControl = new SearchControl();
            addUserControl((SearchControl)searchControl);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ClientControl clientControl = new ClientControl();
            addUserControl(clientControl);
            
        }
        void hienthi()
        {

        }
    }
}
