﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace quanlynganhang1.userControls
{
    public partial class SearchControl : UserControl
    {
        String connect = "Data Source=IT-Number-One\\SQLEXPRESS;Initial Catalog=quanlinganhang;Integrated Security=True;TrustServerCertificate=True";
    
        public SearchControl()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        void load_data()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect; 
            con.Open();
            String sql = "Select * from dsso";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

        }
        private void SearchControl_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * from dsso";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
           
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect; con.Open();
            String sql = "Select * from dsso where MaKH = ('"+textBox3.Text+"')";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            sum();
            username();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            load_data();
        }
        private void sum()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect; 
            con.Open();
            String sql = "Select sum(Sotien) from dsso where MaKH = ('" + textBox3.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            textBox1.Text = rdr.GetValue(0).ToString();
            
        }
        private void username()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect; 
            con.Open();
            String sql = "Select TenKH from dsso where MaKH = ('" + textBox3.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            textBox2.Text = rdr.GetValue(0).ToString();
        }
    }
}
