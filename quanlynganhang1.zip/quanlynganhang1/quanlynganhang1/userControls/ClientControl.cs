﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlynganhang1.userControls
{
    public partial class ClientControl : UserControl
    {
        String connect = "Data Source=IT-Number-One\\SQLEXPRESS;Initial Catalog=quanlinganhang;Integrated Security=True;TrustServerCertificate=True";


        public ClientControl()
        {
            InitializeComponent();
           
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
        void load_data()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * from dskhachhang";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void ClientControl_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * from dskhachhang";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "insert into dskhachhang(TenKH,Diachi,SDT,LoaiKH) values (N'"+textBox1.Text+ "',N'"+textBox2.Text+ "','"+textBox3.Text+ "',N'"+comboBox1.Text+"')";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            load_data();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "update dskhachhang set TenKH = (N'"+textBox1.Text+"'),Diachi = (N'"+textBox2.Text+"'),SDT = ('"+textBox3.Text+"'),LoaiKH = (N'"+comboBox1.Text+"') where MaKH = ('"+textBox4.Text+"')";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            load_data();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            textBox4.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            textBox1.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
        }
    }
}
