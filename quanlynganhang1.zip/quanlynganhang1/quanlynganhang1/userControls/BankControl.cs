﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace quanlynganhang1.userControls
{
    public partial class BankControl : UserControl
    {
        String connect = "Data Source=IT-Number-One\\SQLEXPRESS;Initial Catalog=quanlinganhang;Integrated Security=True;TrustServerCertificate=True";

        public BankControl()
        {
            InitializeComponent();
        }
        void load_data()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * from dsnganhang";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void BankControl_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * from dsnganhang";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "insert into dsnganhang(TenNH,Laixuatgui) values (N'" + textBox1.Text + "',N'" + textBox2.Text + "')";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            load_data();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "update dsnganhang set TenNH = (N'" + textBox1.Text + "'),laixuatgui = (N'" + textBox2.Text + "') where maNH = ('"+textBox3.Text+"')"; 
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            load_data();
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;

            textBox1.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
        }
    }
}
