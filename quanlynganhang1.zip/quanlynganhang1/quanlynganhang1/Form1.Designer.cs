﻿namespace quanlynganhang1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.SearchButton = new Guna.UI2.WinForms.Guna2Button();
            this.SaveButton = new Guna.UI2.WinForms.Guna2Button();
            this.BankButton = new Guna.UI2.WinForms.Guna2Button();
            this.clientButton1 = new Guna.UI2.WinForms.Guna2Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(164, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bank management";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 71);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::quanlynganhang1.Properties.Resources.bank;
            this.pictureBox1.Location = new System.Drawing.Point(40, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 69);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.SearchButton);
            this.panel3.Controls.Add(this.SaveButton);
            this.panel3.Controls.Add(this.BankButton);
            this.panel3.Controls.Add(this.clientButton1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 71);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1067, 77);
            this.panel3.TabIndex = 0;
            // 
            // SearchButton
            // 
            this.SearchButton.CustomBorderColor = System.Drawing.Color.Black;
            this.SearchButton.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.SearchButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SearchButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SearchButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SearchButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SearchButton.FillColor = System.Drawing.Color.Pink;
            this.SearchButton.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.ForeColor = System.Drawing.Color.Black;
            this.SearchButton.Location = new System.Drawing.Point(756, 2);
            this.SearchButton.Margin = new System.Windows.Forms.Padding(0);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.PressedDepth = 0;
            this.SearchButton.Size = new System.Drawing.Size(196, 71);
            this.SearchButton.TabIndex = 6;
            this.SearchButton.Text = "Tìm Kiếm/Thống Kê";
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.CustomBorderColor = System.Drawing.Color.Black;
            this.SaveButton.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.SaveButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SaveButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SaveButton.FillColor = System.Drawing.Color.Pink;
            this.SaveButton.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.Color.Black;
            this.SaveButton.Location = new System.Drawing.Point(537, 2);
            this.SaveButton.Margin = new System.Windows.Forms.Padding(0);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.PressedDepth = 0;
            this.SaveButton.Size = new System.Drawing.Size(219, 71);
            this.SaveButton.TabIndex = 5;
            this.SaveButton.Text = "Sổ Tiết Kiệm";
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // BankButton
            // 
            this.BankButton.CustomBorderColor = System.Drawing.Color.Black;
            this.BankButton.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.BankButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BankButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BankButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BankButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BankButton.FillColor = System.Drawing.Color.Pink;
            this.BankButton.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BankButton.ForeColor = System.Drawing.Color.Black;
            this.BankButton.Location = new System.Drawing.Point(324, 2);
            this.BankButton.Margin = new System.Windows.Forms.Padding(0);
            this.BankButton.Name = "BankButton";
            this.BankButton.PressedDepth = 0;
            this.BankButton.Size = new System.Drawing.Size(214, 71);
            this.BankButton.TabIndex = 4;
            this.BankButton.Text = "Ngân Hàng";
            this.BankButton.Click += new System.EventHandler(this.BankButton_Click);
            // 
            // clientButton1
            // 
            this.clientButton1.CustomBorderColor = System.Drawing.Color.Black;
            this.clientButton1.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.clientButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clientButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clientButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clientButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clientButton1.FillColor = System.Drawing.Color.Pink;
            this.clientButton1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientButton1.ForeColor = System.Drawing.Color.Black;
            this.clientButton1.Location = new System.Drawing.Point(105, 2);
            this.clientButton1.Margin = new System.Windows.Forms.Padding(0);
            this.clientButton1.Name = "clientButton1";
            this.clientButton1.PressedDepth = 0;
            this.clientButton1.Size = new System.Drawing.Size(219, 71);
            this.clientButton1.TabIndex = 3;
            this.clientButton1.Text = "Khách Hàng";
            this.clientButton1.Click += new System.EventHandler(this.clientButton1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(607, 287);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(8, 8);
            this.button2.TabIndex = 2;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 148);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1067, 453);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1067, 601);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private Guna.UI2.WinForms.Guna2Button clientButton1;
        private Guna.UI2.WinForms.Guna2Button SearchButton;
        private Guna.UI2.WinForms.Guna2Button SaveButton;
        private Guna.UI2.WinForms.Guna2Button BankButton;
        private System.Windows.Forms.Panel panel2;
    }
}

