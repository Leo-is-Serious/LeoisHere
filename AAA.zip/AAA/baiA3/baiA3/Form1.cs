using System.Data;
using System.Data.SqlClient;

namespace baiA3
{
    public partial class Form1 : Form
    {
        String connect = @"Data Source=IT-Number-One\SQLEXPRESS;Initial Catalog=TRY_HARD;Integrated Security=True;TrustServerCertificate=True";
        public Form1()
        {
            InitializeComponent();
        }
        void load_data()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * From Sach";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Select * From Sach";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            textBox4.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox5.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "Insert into Sach(Masach,Tensach,Nhaxuatban,Namxuatban,Giatien) values ('"+textBox1.Text+ "',N'"+textBox4.Text+"',N'"+textBox5.Text+"',N'"+textBox3.Text+"','"+textBox2.Text+"')     ";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            
            con.Close();
            load_data();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = " UPDATE SACH   SET Tensach = N'" + textBox4.Text + "',Nhaxuatban =  N'" + textBox5.Text + "',Namxuatban = N'" + textBox3.Text + "',Giatien = '" + textBox2.Text + "' where masach = '"+textBox1.Text+"'     ";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            con.Close();
            load_data();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = connect;
            con.Open();
            String sql = "DELETE FROM SACH WHERE Masach = ('" + textBox1.Text + "')";
            DataSet ds = new DataSet();
            ds.Clear();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            
            con.Close();
            load_data();
        }

       
    }
}
