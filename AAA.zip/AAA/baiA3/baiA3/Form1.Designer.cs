﻿namespace baiA3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label6 = new Label();
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            Masach = new DataGridViewTextBoxColumn();
            Tensach = new DataGridViewTextBoxColumn();
            Nhaxuatban = new DataGridViewTextBoxColumn();
            Namxuatban = new DataGridViewTextBoxColumn();
            Giatien = new DataGridViewTextBoxColumn();
            panel3 = new Panel();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label5 = new Label();
            textBox5 = new TextBox();
            label4 = new Label();
            textBox4 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label2 = new Label();
            textBox2 = new TextBox();
            label1 = new Label();
            textBox1 = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(label6);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1302, 99);
            panel1.TabIndex = 0;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(436, 30);
            label6.Name = "label6";
            label6.Size = new Size(314, 35);
            label6.TabIndex = 2;
            label6.Text = "Quản lý thông tin sách";
            // 
            // panel2
            // 
            panel2.Controls.Add(dataGridView1);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 422);
            panel2.Name = "panel2";
            panel2.Size = new Size(1302, 336);
            panel2.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Masach, Tensach, Nhaxuatban, Namxuatban, Giatien });
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1302, 336);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // Masach
            // 
            Masach.DataPropertyName = "Masach";
            Masach.HeaderText = "Mã sách";
            Masach.MinimumWidth = 6;
            Masach.Name = "Masach";
            Masach.ReadOnly = true;
            Masach.Width = 200;
            // 
            // Tensach
            // 
            Tensach.DataPropertyName = "Tensach";
            Tensach.HeaderText = "Tên sách";
            Tensach.MinimumWidth = 6;
            Tensach.Name = "Tensach";
            Tensach.ReadOnly = true;
            Tensach.Width = 325;
            // 
            // Nhaxuatban
            // 
            Nhaxuatban.DataPropertyName = "Nhaxuatban";
            Nhaxuatban.HeaderText = "Nhà xuất bản";
            Nhaxuatban.MinimumWidth = 6;
            Nhaxuatban.Name = "Nhaxuatban";
            Nhaxuatban.ReadOnly = true;
            Nhaxuatban.Width = 325;
            // 
            // Namxuatban
            // 
            Namxuatban.DataPropertyName = "Namxuatban";
            Namxuatban.HeaderText = "Năm xuất bản";
            Namxuatban.MinimumWidth = 6;
            Namxuatban.Name = "Namxuatban";
            Namxuatban.ReadOnly = true;
            Namxuatban.Width = 150;
            // 
            // Giatien
            // 
            Giatien.DataPropertyName = "Giatien";
            Giatien.HeaderText = "Giá tiền";
            Giatien.MinimumWidth = 6;
            Giatien.Name = "Giatien";
            Giatien.ReadOnly = true;
            Giatien.Width = 250;
            // 
            // panel3
            // 
            panel3.Controls.Add(button3);
            panel3.Controls.Add(button2);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(textBox5);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(textBox4);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(textBox3);
            panel3.Controls.Add(label2);
            panel3.Controls.Add(textBox2);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(textBox1);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 99);
            panel3.Name = "panel3";
            panel3.Size = new Size(1302, 323);
            panel3.TabIndex = 2;
            // 
            // button3
            // 
            button3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(912, 248);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 12;
            button3.Text = "Xóa";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(527, 248);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 11;
            button2.Text = "Sửa ";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(172, 248);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 10;
            button1.Text = "Thêm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(97, 106);
            label5.Name = "label5";
            label5.Size = new Size(94, 23);
            label5.TabIndex = 9;
            label5.Text = "Nhà XB : ";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(197, 102);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(400, 27);
            textBox5.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(650, 106);
            label4.Name = "label4";
            label4.Size = new Size(100, 23);
            label4.TabIndex = 7;
            label4.Text = "Năm XB : ";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(764, 45);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(467, 27);
            textBox4.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(97, 171);
            label3.Name = "label3";
            label3.Size = new Size(101, 23);
            label3.TabIndex = 5;
            label3.Text = "Giá Tiền : ";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(777, 102);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(305, 27);
            textBox3.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(650, 49);
            label2.Name = "label2";
            label2.Size = new Size(108, 23);
            label2.TabIndex = 3;
            label2.Text = "Tên sách : ";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(206, 167);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(261, 27);
            textBox2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(97, 45);
            label1.Name = "label1";
            label1.Size = new Size(103, 23);
            label1.TabIndex = 1;
            label1.Text = "Mã sách : ";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(206, 41);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(310, 27);
            textBox1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1302, 758);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label5;
        private TextBox textBox5;
        private Label label4;
        private TextBox textBox4;
        private Label label3;
        private TextBox textBox3;
        private Label label2;
        private TextBox textBox2;
        private Label label1;
        private TextBox textBox1;
        private Label label6;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridViewTextBoxColumn Masach;
        private DataGridViewTextBoxColumn Tensach;
        private DataGridViewTextBoxColumn Nhaxuatban;
        private DataGridViewTextBoxColumn Namxuatban;
        private DataGridViewTextBoxColumn Giatien;
    }
}
