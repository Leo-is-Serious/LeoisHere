﻿
----Tạo database---
CREATE DATABASE TRY_HARD;
USE TRY_HARD;
set ansi_nulls on;
set quoted_identifier on;

----tạo bảng-----
CREATE TABLE SACH(
masach varchar(10) primary key ,
Tensach nvarchar(250) ,
Nhaxuatban nvarchar(250) ,
Namxuatban varchar(30) ,
Giatien bigint );

-----Thêm dữ liệu vào bảng----
insert into SACH(masach,Tensach,Nhaxuatban,Namxuatban,Giatien) values
('1',N'Thám Tử Lừng Danh Conan',N'Aoyama Gōshō','1994','20000');
insert into SACH(masach,Tensach,Nhaxuatban,Namxuatban,Giatien) values
('2',N'Lược Sử Loài Người',N'Yuval Noah Harari','2011','200000');
insert into SACH(masach,Tensach,Nhaxuatban,Namxuatban,Giatien) values
('3',N'Đắc Nhân Tâm',N'Dale Carnegie','1936','120000');
insert into SACH(masach,Tensach,Nhaxuatban,Namxuatban,Giatien) values
('4',N'Cô Gái Năm Ấy Chúng Ta Cùng Theo Đuổi',N'Cửu Bả Đao','2005','150000');



----Một số câu truy vấn 
--Select * from SACH ;

---DELETE FROM SACH 
---WHERE masach = '4';
---DROP TABLE SACH;